
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/i2c.h>
#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/delay.h>
#include <linux/ide.h>
#include <linux/errno.h>
#include <linux/gpio.h>
#include <asm/mach/map.h>
#include <linux/of.h>
#include <linux/of_address.h>
#include <linux/of_gpio.h>
#include <asm/io.h>
#include <linux/device.h>

#include <linux/platform_device.h>

#include "i2c_oled.h"
#include "font.c"
/*------------------字符设备内容----------------------*/
#define DEV_NAME "I2C1_oled"
#define DEV_CNT (1)
#define WriteCmd(client, cmd) i2c_write_oled(client, 0x00, cmd)
#define WriteDat(client, data) i2c_write_oled(client, 0x40, data)
/*定义 led 资源结构体，保存获取得到的节点信息以及转换后的虚拟寄存器地址*/
static dev_t oled_devno;				 //定义字符设备的设备号
static struct cdev oled_chr_dev;		 //定义字符设备结构体chr_dev
struct class *class_oled;			 //保存创建的类
struct device *device_oled;			 // 保存创建的设备
struct device_node *oled_device_node; //rgb_led的设备树节点结构体

/*------------------IIC设备内容----------------------*/
struct i2c_client *oled_client = NULL; //保存mpu6050设备对应的i2c_client结构体，匹配成功后由.prob函数带回。
static void OLED_Cls(struct i2c_client *client);
char str_oled[10]="Hello";
void OLED_Set(struct i2c_client *client, const char *str);
/*通过i2c 向mpu6050写入数据
*mpu6050_client：mpu6050的i2c_client结构体。
*address, 数据要写入的地址，
*data, 要写入的数据
*返回值，错误，-1。成功，0  
*/
static int i2c_write_oled(struct i2c_client *oled_client, u8 address, u8 data)
{
	int error = 0;
	u8 write_data[2];
	struct i2c_msg send_msg; //要发送的数据结构体

	/*设置要发送的数据*/
	write_data[0] = address;
	write_data[1] = data;

	/*发送 iic要写入的地址 reg*/
	send_msg.addr = oled_client->addr; //mpu6050在 iic 总线上的地址
	send_msg.flags = 0;					  //标记为发送数据
	send_msg.buf = write_data;			  //写入的首地址
	send_msg.len = 2;					  //reg长度

	/*执行发送*/
	error = i2c_transfer(oled_client->adapter, &send_msg, 1);
	if (error != 1)
	{
		printk(KERN_DEBUG "\n i2c_transfer error \n");
		return -1;
	}
	return 0;
}

//static int i2c_read_oled(struct i2c_client *oled_client, u8 address, void *data, u32 length)
//{

//	return 0;
//}
static void OLED_SetPos(struct i2c_client *client, uint8_t x, uint8_t y)
{
	WriteCmd(client, ((x & 0xF0) >> 4) | 0x10);
	WriteCmd(client, x & 0x0F);
	WriteCmd(client, 0xB0 + (y % 8));
}

static void OLED_Cls(struct i2c_client *client)
{
	uint8_t m, n;
	for (m = 0; m < 8; m++)
	{
		WriteCmd(client, 0xB0 + m);
		WriteCmd(client, 0x00);
		WriteCmd(client, 0x10);
		for (n = 0; n < 128; n++)
		{
			WriteDat(client, 0x00);
		}
	}
}

void OLED_Set(struct i2c_client *client, const char *str)
{
	uint8_t i, j, x, y;
	char ch;
	const uint8_t *buf;
	OLED_Cls(client);
	OLED_SetPos(client, 0, 0);
	x = 0;
	y = 0;
	for (i = 0, ch = *str; ch; ch = *(str + ++i))
	{
		if (ch < ' ' || ch > 'z')
		{
			ch = ' ';
		}
		buf = F6x8 + (6 * (ch - 0x20));
		OLED_SetPos(client, x, y);
		for (j = 0; j < 6; j++)
		{
			if (x < 128 && y < 64)
			{
				WriteDat(client, *(buf + j));
			}
			x++;
		}
		if (x + 6 >= 128)
		{
			x = 0;
			y++; // y一个就8行
			if (y >= 64)
			{
				return;
			}
		}
	}
}
/*初始化i2c
*返回值，成功，返回0。失败，返回 -1
*/
static int oled_init(struct i2c_client *client)
{
	int error = 0;
	error+=WriteCmd(client, 0xAE); //display off
	error+=WriteCmd(client, 0x20);	//Set Memory Addressing Mode	
	error+=WriteCmd(client, 0x10);	//00,Horizontal Addressing Mode;01,Vertical Addressing Mode;10,Page Addressing Mode (RESET);11,Invalid
	error+=WriteCmd(client, 0xb0);	//00,Horizontal Addressing Mode
	error+=WriteCmd(client, 0xc8);	//Set Page Start Address for Page Addressing Mode,0-7
	error+=WriteCmd(client, 0x00);	//Set COM Output Scan Direction

	error+=WriteCmd(client, 0x10); //亮度调节 0x00~0xff
	error+=WriteCmd(client, 0x40); //--set segment re-map 0 to 127
	error+=WriteCmd(client, 0x81); //--set normal display
	error+=WriteCmd(client, 0xff); //--set multiplex ratio(1 to 64)
	error+=WriteCmd(client, 0xa1); //
	error+=WriteCmd(client, 0xa6); //
	error+=WriteCmd(client, 0xa8); //-set display offset
	error+=WriteCmd(client, 0x3f); //-not offset

	error+=WriteCmd(client, 0xa4); //--set display clock divide ratio/oscillator frequency
	error+=WriteCmd(client, 0xd3); //--set display clock divide ratio/oscillator frequency

	error+=WriteCmd(client, 0x00); //--set divide ratio
	error+=WriteCmd(client, 0xd5); //--set pre-charge period
	error+=WriteCmd(client, 0xf0); //
	error+=WriteCmd(client, 0xd9); //--set com pins hardware configuration
	error+=WriteCmd(client, 0x22);
	error+=WriteCmd(client, 0xda); //--set vcomh
	error+=WriteCmd(client, 0x12); //0x20,0.77xVcc
	error+=WriteCmd(client, 0xdb); //--set DC-DC enable

	error+=WriteCmd(client, 0x20); //--set DC-DC enable
	error+=WriteCmd(client, 0x8d); //--set vcomh
	error+=WriteCmd(client, 0x14); //0x20,0.77xVcc
	error+=WriteCmd(client, 0xaf); //--set DC-DC enable

	if (error < 0)
	{
		/*初始化错误*/
		printk(KERN_DEBUG "\n oled_init error \n");
		return -1;
	}
	OLED_Set(client,str_oled);
	return 0;
}

/*字符设备操作函数集，open函数实现*/
static int oled_open(struct inode *inode, struct file *filp)
{
	// printk("\n mpu6050_open \n");

	/*向 mpu6050 发送配置数据，让mpu6050处于正常工作状态*/
	oled_init(oled_client);
	return 0;
}

/*字符设备操作函数集，.read函数实现*/
static ssize_t oled_read(struct file *filp, char __user *buf, size_t cnt, loff_t *off)
{
	return 0;
}

/*字符设备操作函数集，.release函数实现*/
static int oled_release(struct inode *inode, struct file *filp)
{
	// printk("\n mpu6050_release \n");
	
	/*向mpu6050发送命令，使mpu6050进入关机状态*/
	return 0;
}
static ssize_t dev_write(struct file *file, const char __user *buf, size_t count, loff_t *fpos)
{
	char *str = vmalloc(count);
	if (copy_from_user(str, buf, count))
	{
		vfree(str);
		return -EFAULT;
	}
	*(str + count) = '\0';
	OLED_Set(oled_client, str);
	vfree(str);
	return count;
}

/*字符设备操作函数集*/
static struct file_operations oled_chr_dev_fops =
	{
		.owner = THIS_MODULE,
		.open = oled_open,
		.read = oled_read,
		.write = &dev_write,
		.release = oled_release,
};

/*----------------平台驱动函数集-----------------*/
static int oled_probe(struct i2c_client *client, const struct i2c_device_id *id)
{

	int ret = -1; //保存错误状态码

	printk(KERN_EMERG "\t  match successed  \n");
	/*---------------------注册 字符设备部分-----------------*/

	//采用动态分配的方式，获取设备编号，次设备号为0，
	//设备名称为rgb-leds，可通过命令cat  /proc/devices查看
	//DEV_CNT为1，当前只申请一个设备编号
	ret = alloc_chrdev_region(&oled_devno, 0, DEV_CNT, DEV_NAME);
	if (ret < 0)
	{
		printk("fail to alloc oled_devno\n");
		goto alloc_err;
	}

	//关联字符设备结构体cdev与文件操作结构体file_operations
	oled_chr_dev.owner = THIS_MODULE;
	cdev_init(&oled_chr_dev, &oled_chr_dev_fops);

	// 添加设备至cdev_map散列表中
	ret = cdev_add(&oled_chr_dev, oled_devno, DEV_CNT);
	if (ret < 0)
	{
		printk("fail to add cdev\n");
		goto add_err;
	}

	/*创建类 */
	class_oled = class_create(THIS_MODULE, DEV_NAME);

	/*创建设备 DEV_NAME 指定设备名，*/
	device_oled = device_create(class_oled, NULL, oled_devno, NULL, DEV_NAME);
	oled_client = client;
	return 0;

add_err:
	// 添加设备失败时，需要注销设备号
	unregister_chrdev_region(oled_devno, DEV_CNT);
	printk("\n error! \n");
alloc_err:

	return -1;
}


static int oled_remove(struct i2c_client *client)
{
	/*删除设备*/
	device_destroy(class_oled, oled_devno);	  //清除设备
	class_destroy(class_oled);					  //清除类
	cdev_del(&oled_chr_dev);						  //清除设备号
	unregister_chrdev_region(oled_devno, DEV_CNT); //取消注册字符设备
	return 0;
}



/*定义ID 匹配表*/
static const struct i2c_device_id gtp_device_id[] = {
	{"fire,i2c_oled", 0},
	{}};

/*定义设备树匹配表*/
static const struct of_device_id oled_of_match_table[] = {
	{.compatible = "fire,i2c_oled"},
	{/* sentinel */}};

/*定义i2c总线设备结构体*/
struct i2c_driver oled_driver = {
	.probe = oled_probe,
	.remove = oled_remove,
	.id_table = gtp_device_id,
	.driver = {
		.name = "fire,i2c_oled",
		.owner = THIS_MODULE,
		.of_match_table = oled_of_match_table,
	},
};

/*
*驱动初始化函数
*/
static int __init oled_driver_init(void)
{
	int ret;
	pr_info("oled_driver_init\n");
	ret = i2c_add_driver(&oled_driver);
	return ret;
}

/*
*驱动注销函数
*/
static void __exit oled_driver_exit(void)
{
	pr_info("oled_driver_exit\n");
	i2c_del_driver(&oled_driver);
}

module_init(oled_driver_init);
module_exit(oled_driver_exit);

MODULE_LICENSE("GPL");
